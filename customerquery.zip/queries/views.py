from queries.models import Query
from django.http.response import JsonResponse
from django.shortcuts import redirect, render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
from queries.serializers import QuerySerializer
from rest_framework.parsers import JSONParser
from rest_framework import status
import requests

@csrf_exempt
def AddQuery(request):
    if(request.method=="POST"):
        # mydata=JSONParser().parse(request)
        Query_serialize=QuerySerializer(data=request.POST)
        if(Query_serialize.is_valid()):
            Query_serialize.save()
            return redirect(myViewAllQuery)
            # return JsonResponse(Query_serialize.data,status=status.HTTP_200_OK)
        else:
            return HttpResponse("Error in Serialization",status=status.HTTP_400_BAD_REQUEST)
    else:
        return HttpResponse("GET Method Not Allowed",status=status.HTTP_404_NOT_FOUND)

def registerquery(request):
    return render(request,'registerquery.html')

@csrf_exempt
def Query_List(request):
    if(request.method=="GET"):
        q1=Query.objects.all()
        q_serializer=QuerySerializer(q1,many=True)
        return JsonResponse(q_serializer.data,safe=False)

@csrf_exempt
def Query_Delete(request,id):
    try:
        q1=Query.objects.get(id=id)
        if (request.method=="DELETE"):  
                q1.delete()
                return HttpResponse("Deleted",status=status.HTTP_204_NO_CONTENT)
    except Query.DoesNotExist:
        return HttpResponse("Invalid",status=status.HTTP_404_NOT_FOUND)

@csrf_exempt
def DeleteReadQuery(request):
    getNewId=request.POST.get("newid")
    ApiLink="http://127.0.0.1:8000/queries/deletequeries/" + getNewId
    requests.delete(ApiLink)
    return redirect(myViewAllQuery)

@csrf_exempt
def DeleteSearchQuery(request):
    try:
        getmobile=request.POST.get("mobile")
        getmob=Query.objects.filter(mobile=getmobile)
        q_serializer=QuerySerializer(getmob,many=True)
        return render(request,"deletequery.html",{"data":q_serializer.data})
        #return JsonResponse(prepaidplans_serializer.data,safe=False,status=status.HTTP_200_OK)
    except Query.DoesNotExist:
        return HttpResponse("Invalid",status=status.HTTP_404_NOT_FOUND)
    except:
        return HttpResponse("Something Wrong")

@csrf_exempt
def myDeleteQuery(request):
    return render(request,'deletequery.html')




def myViewAllQuery(request):
    fetchdata=requests.get("http://127.0.0.1:8000/queries/viewallq/").json()
    return render(request,'viewallquery.html',{"data":fetchdata})

def myHeaderPage(request):
    return render(request,'header.html')



from django.urls import path, include
from . import views

urlpatterns = [
    path('addquery/',views.AddQuery,name='Addqueryapi'),
    path('deletequery/<id>',views.Query_Delete,name='query_Deleteapi'),
    path('viewallq/',views.Query_List,name='Query_List'),
    path('deletereadquery/',views.DeleteReadQuery,name='Deletereadquery'),
    path('deletequeries/',views.DeleteSearchQuery,name='DeleteSearchprepaidplans'),








path('registerquery/',views.registerquery,name='registerquerypage'),
path('viewallqueries/',views.myViewAllQuery,name='myViewAllQuerypage'),
path('deletequery/',views.myDeleteQuery,name='myDeleteQuerypage'),


]




from django.db import models

class Query(models.Model):
    
    name=models.CharField(max_length=50)
    mobile=models.CharField(max_length=50)
    message=models.CharField(max_length=50)

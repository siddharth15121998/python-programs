from django.shortcuts import render,redirect
from django.http import HttpResponse,JsonResponse
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
import requests,json


# Create your views here.
def Home_Page(request):
    return render(request,'home.html')


def About_us(request):
    return render(request,'aboutus.html')

def contact_us(request):
    return render(request,'contactus.html')

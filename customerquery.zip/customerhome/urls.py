from . import views
from django.urls import path,include

urlpatterns = [
   
    path('home/',views.Home_Page,name='Home_Page'),
    path('contactus/',views.contact_us,name='contact_us'),
    path('aboutus/',views.About_us,name='about_us'),
    
    
    
    
    
    
    ]
    